

// MapExemplaire.get(89).disponibilite = false;
// console.log(MapExemplaire);

// MapExemplaire.get(89).disponibilite = false;
// console.log(MapExemplaire);